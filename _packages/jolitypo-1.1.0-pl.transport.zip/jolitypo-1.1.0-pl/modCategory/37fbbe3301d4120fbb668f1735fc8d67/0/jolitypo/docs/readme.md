## JoliTypo for MODX

Use JoliTypo for Microtypography as Output Filter in MODX.

Download Extra via Package Installer: https://extras.modx.com/package/jolitypo
Official JoliTypo Documentation: https://github.com/jolicode/JoliTypo