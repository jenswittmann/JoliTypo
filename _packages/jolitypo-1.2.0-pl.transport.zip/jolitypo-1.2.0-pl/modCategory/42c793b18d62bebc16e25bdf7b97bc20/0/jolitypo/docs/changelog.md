## JoliTypo 1.2.0

Released on 2024-07-30

- bugfix: prevent MODX URL modifier gets encoded in links when pdoTools are installed (#4)

## JoliTypo 1.1.1

Released on 2024-03-12

- revert bugfix: [[~1]] gets encoded by JoliTypo (#3)

## JoliTypo 1.1.0

Released on 2024-01-16

- use composer on package install (thanks to https://github.com/Jako/FilterWhere/blob/master/_build/resolvers/resolve.composer.php)
- drop support for PHP < 7.4
- bugfix: [[~1]] gets encoded by JoliTypo (#2)

## JoliTypo 1.0.0

Released on 2022-01-06

- move config completely to system_settings
- update JoliTypo to 1.2.0
- add custom replaces 

## JoliTypo 0.9.0

Released on 2019-01-03

- initial commit